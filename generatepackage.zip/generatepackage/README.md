# GeneratePackage

## how to use
run script using sh generatePackage follow the instructions (don't double click the script).

if folder contains .app has spaces in name then add \(space) e.x. hello hi then hello\ hi

e.x. users/systemusername/desktop/app/


Successfull Output
pkgbuild: Adding top-level postinstall script
pkgbuild: Wrote package to <APPNAME>.pkg
Moving package to desktop...
Package moved
